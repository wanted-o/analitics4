<?php
/**
 * @package		Google Analytics Dashboard - Module for Joomla!
 * @author		Alin Marcu - https://deconf.com
 * @copyright	Copyright (c) 2010 - 2012 DeConf.com
 * @license		GNU/GPL license: http://www.gnu.org/licenses/gpl-2.0.html
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' ); // no direct access

JHtml::_( 'jquery.framework' );

echo '<div style="text-align:center;">' . $output . '</div>';
?>
